# bx — B / Integrated — Production Asset Pack v3

This pack was rebuilt after a full display audit.

## What was wrong in v2
1. The dark-background color mark was accidentally overwritten by the white monochrome export.
2. The generic black+blue transparent mark was easy to use on dark UI, where the graphite `b` nearly disappeared.
3. 16/32px favicons used the full app tile, making the bx glyph too small.
4. Raster-embedded SVG wrappers were mixed with runtime assets and could render inconsistently in some consumers.
5. Transparent mark edges retained some light-matte contamination from the generated board.

## Fixed in v3
- Separate, explicit `ui_mark/on_light/` and `ui_mark/on_dark/` variants.
- Cleaned edge colors to remove light halos on dark/gray backgrounds.
- Dedicated optical-size favicon exports for 16/32/48/64px.
- Runtime assets are PNG/ICO/iconset; SVG raster wrappers moved to `reference/svg_wrappers/`.
- Added contact-sheet and contrast QA images.

## Use with Claude
- macOS app icon: `macos/Bx.iconset/`
- system dialog on light UI: `app_icon/light/bx-128.png` or `bx-64.png`
- system dialog on dark UI: `app_icon/dark/bx-128.png` or `bx-64.png`
- standalone mark on light UI: `ui_mark/on_light/`
- standalone mark on dark UI: `ui_mark/on_dark/`
- browser favicon: `web/favicon/`
- PWA icons: `web/pwa/`
- Windows icon: `windows/bx.ico`

**Do not change the existing macOS menu-bar shield.** It represents protection state, while the bx mark represents product identity.
